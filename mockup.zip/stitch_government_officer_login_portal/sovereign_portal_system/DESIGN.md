---
name: Sovereign Portal System
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#e2bfb2'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#a98a7e'
  outline-variant: '#5a4138'
  surface-tint: '#ffb599'
  primary: '#ffb599'
  on-primary: '#5a1c00'
  primary-container: '#ff671f'
  on-primary-container: '#591b00'
  inverse-primary: '#a73a00'
  secondary: '#83d99b'
  on-secondary: '#00391b'
  secondary-container: '#006836'
  on-secondary-container: '#8de4a5'
  tertiary: '#b1c5ff'
  on-tertiary: '#072d6c'
  tertiary-container: '#7b96dc'
  on-tertiary-container: '#062c6c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdbce'
  primary-fixed-dim: '#ffb599'
  on-primary-fixed: '#370e00'
  on-primary-fixed-variant: '#7f2b00'
  secondary-fixed: '#9ef6b6'
  secondary-fixed-dim: '#83d99b'
  on-secondary-fixed: '#00210d'
  on-secondary-fixed-variant: '#00522a'
  tertiary-fixed: '#dae2ff'
  tertiary-fixed-dim: '#b1c5ff'
  on-tertiary-fixed: '#001946'
  on-tertiary-fixed-variant: '#274484'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  headline-xl:
    fontFamily: Roboto Flex
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Roboto Flex
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Roboto Flex
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Roboto Flex
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  title-md:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Roboto Flex
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Roboto Flex
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.06em
  label-mono-security:
    fontFamily: Roboto Flex
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.12em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 3rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system embodies solemn institutional authority, absolute digital sovereignty, and rigorous security for high-clearance government personnel. Designed for national administrative, defense, and civilian officers, the visual register avoids decorative excess in favor of crisp, purposeful minimalism that instills focus, trust, and gravity.

The design movement combines **Minimalism** with **Low-Contrast Structural Precision**:
- Surfaces remain deeply anchored in near-black charcoal tones, eliminating visual fatigue during prolonged shifts.
- Accents reference the national visual identity through measured, micro-dosed tricolor highlights—India Saffron (`#FF671F`), Crisp White (`#FFFFFF`), and India Green (`#046A38`), underpinned by Ashoka Chakra Navy (`#002868`) for authoritative anchor points.
- Visual elements favor strict alignment, razor-sharp demarcations, and understated metadata over expressive animations or consumer flourishes.

## Colors

The color architecture is built around an austere dark hierarchy illuminated by targeted, high-meaning spectral signals.

### Core Canvas & Surfaces
- **Canvas Base (`#0A0A0A`)**: Ground layer for entire screens and full-bleed viewport roots.
- **Surface Level 1 (`#121212`)**: Primary card panels, authentication containers, and toolbars.
- **Surface Level 2 (`#1E1E1E`)**: Input backdrops, nested utility drawers, and segmented controls.
- **Surface Level 3 / Border Accent (`#2A2A2A`)**: Standard separation boundaries and default dividers.
- **Structural Stroke (`#3F3F46`)**: Active perimeter rings, keyline dividers, and accessible frame lines.

### National & Status Indicators
- **Primary / India Saffron (`#FF671F`)**: Reserved strictly for high-visibility interactive actions, security notice anchors, critical alert cues, and primary submit states.
- **Secondary / India Green (`#046A38`)**: Validated security clearance states, success notifications, operational verification pings, and certified digital signatures.
- **Tertiary / Ashoka Navy (`#002868`)**: Watermark foundations, structural banner sub-bars, and cryptographic status badges.
- **Neutral White (`#FFFFFF`)**: Primary headline text, critical system indicators, and the central crest element.
- **Muted Gray (`#A1A1AA`)**: Secondary explanatory text, field labels, and security disclaimers.
- **Subtle Gray (`#71717A`)**: Inactive iconography, placeholder text, and system telemetry stamps.

## Typography

The typography relies entirely on **Roboto Flex** to ensure universal institutional clarity, high legibility across legacy monitors, and deterministic rendering under constrained network profiles.

- **Weight Hierarchy**: Primary titles leverage `Weight 700` and `600` to anchor institutional authority. Body and interactive components use `Weight 400` and `500` to prevent visual bloat.
- **Casing and Tracking**: Form field labels, cryptographic verification hashes, and security clearance identifiers leverage uppercase tracking (`0.05em` to `0.12em`) via `label-md` and `label-mono-security`.
- **Contrast Ratios**: All primary readable text targets a minimum contrast ratio of 10:1 against `#0A0A0A` and `#121212`, ensuring compliance with mandatory government accessibility directives.

## Layout & Spacing

The portal layout adheres to a centralized, monolithic fixed-grid architecture designed to minimize distraction and prioritize singular, high-assurance authentication flows.

### Screen Grids and Container Constraints
- **Desktop (>= 1024px)**: Single central security card constrained to a maximum width of `460px` for authentication views, or a 12-column layout with `gutter: 1.5rem` and outer page `margin: 3rem` for post-login dashboard modules.
- **Tablet (768px – 1023px)**: Centralized card width set to `420px`, outer page margins dynamically set to `2rem`.
- **Mobile (< 768px)**: Fluid viewport execution using `margin-mobile: 1.25rem` and `gutter-mobile: 1rem`. Form elements occupy full container width.

### Spacing Cadence
Spacing follows an exact 4px/8px modular scale. Form components maintain strict internal vertical pacing using `space-md` (`1rem`) between form groups and `space-xs` (`0.25rem`) between input labels and entry boxes. Critical actions are offset by `space-xl` (`2.5rem`) to prevent accidental submissions.

## Elevation & Depth

To preserve the solemn, low-emissivity atmosphere required for a secure dark interface, elevation is conveyed through **tonal layering and low-contrast keylines** rather than dramatic cast shadows.

- **Level 0 (Canvas Base)**: `#0A0A0A`. No border or shadow.
- **Level 1 (Card Panels / Modules)**: `#121212` resting on `#0A0A0A`, bounded by a continuous 1px keyline stroke of `#2A2A2A`.
- **Level 2 (Active Fields, Overlays, Dialogs)**: `#1E1E1E` surface with a 1px boundary of `#3F3F46`. A subtle, highly diffused shadow (`0px 8px 24px rgba(0, 0, 0, 0.65)`) provides focus separation without soft visual ambiguity.
- **Focus / Security Highlight**: Dynamic elevation creates no vertical lift; instead, it reinforces the boundary via a dual stroke: an inner 1px border of `#FF671F` and an outer 2px translucent aura of `rgba(255, 103, 31, 0.25)`.
- **National Tricolor Keyline**: A 2px high horizontal micro-stripe (India Saffron, Crisp White, India Green in equal thirds) crowns the primary login container card, serving as an authenticating masthead.

## Shapes

The visual language requires strict geometrical discipline. Roundedness is anchored to level `1` (Soft), maintaining a near-rectangular, machined feel:
- **Base Components (Inputs, Buttons, Badges)**: Bounded by `0.25rem` (4px) radii. This provides just enough softness to avoid harsh pixel aliasing while communicating institutional discipline.
- **Containers & Surface Cards**: Bounded by `0.5rem` (8px via `rounded-lg`).
- **Pills / Chips**: High-security identity stamps and status chips use a hard-clipped `0.25rem` border radius rather than rounded pill ends, maintaining architectural stability across the UI.

## Components

### 1. Buttons
- **Primary Authentication Action**: Solid `#FF671F` (India Saffron) background, `#0A0A0A` text in `label-lg` uppercase, `0.25rem` corner radius, 48px height. On hover, background shifts to `#E05A1B`. Focus state initiates the saffron dual-glow ring.
- **Secondary / Token / e-Sign Action**: Transparent surface with a 1px `#3F3F46` border, `#FFFFFF` text. On hover, surface shifts to `#1E1E1E` and border to `#FFFFFF`.
- **Emergency / Revoke**: High-contrast outline in `#EF4444` with transparent fill and `12px` monospaced uppercase labeling.

### 2. Input Fields
- **Container**: Fixed height of 44px, background `#121212`, border 1px solid `#2A2A2A`, corner radius `0.25rem`, text `#FFFFFF` in `body-md`.
- **Labels**: Positioned persistently above input fields using `label-md`, colored in `#A1A1AA`, uppercase with `0.05em` letter spacing.
- **Focus State**: Border transitions to `#FF671F`, inner background shifts to `#1E1E1E`.
- **Specialized Security Variant (OTP / Officer PIN)**: Individual segmented boxes (48px × 56px) displaying centered monospace values with an active cursor underline in `#FF671F`.

### 3. Checkboxes & Radio Buttons
- **Geometry**: Checkboxes utilize a sharp 2px radius; radios are circular with an internal 6px solid dot.
- **Unchecked**: Background `#121212`, 1px solid border `#3F3F46`.
- **Checked**: Background `#002868` (Ashoka Navy) with a crisp `#FFFFFF` checkmark or interior pip, bordered by `#FFFFFF`.

### 4. Cards & Containers
- Built on `#121212` with a 1px solid outline in `#2A2A2A`.
- Top edge incorporates the signature 2px tricolor indicator bar (`#FF671F` / `#FFFFFF` / `#046A38`).
- Internal padding is locked to `space-xl` (`2.5rem`) on desktop and `space-md` (`1rem`) on mobile.

### 5. Chips & Badges
- **Security Clearance Badge**: Background `#1E1E1E`, 1px solid border `#002868`, text `#FFFFFF`, prefixed by a blinking status dot in `#046A38` (Active) or `#FF671F` (Restricted).
- All chips utilize `label-mono-security` with all-caps tracking.

### 6. Additional Domain-Specific Elements
- **Cryptographic Watermark / Officer Session Counter**: Fixed anchored footer counter styled in `#71717A` with live ping status (`#046A38`), tracking session validity and token expiry down to the second.
- **Emblem Frame**: A restrained, monochrome zinc-rendered National Emblem or departmental insignia centered above the primary card, precisely 64px in height with 40% opacity.